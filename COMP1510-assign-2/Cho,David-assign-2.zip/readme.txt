[David Cho], [20767689], [C], [2023-03-12]

This assignment is [100]% complete.


------------------------
Question one (MultiCylinder) status:

[complete]
[explanation if not complete, what is working/not working]

------------------------
Question two (WordCounter) status:

[complete]
[explanation if not complete, what is working/not working]

------------------------
Question three (Primes) status:

[complete]
[explanation if not complete, what is working/not working]

------------------------
Question four (Exponential) status:

[complete]
[explanation if not complete, what is working/not working]

------------------------
